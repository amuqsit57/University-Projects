import Classes.Admin;
import Classes.User;
import Costumer.Cart;
import Costumer.Edit;
import Costumer.HomeScreen;
import Costumer.Menu;
import FileOperations.FileOperationsOnAdmin;
import FileOperations.FileOperationsOnLoginAndSignup;
import LoginAndSignup.LoginScreenUser;
import Manager.*;

import java.awt.*;

public class Main {
    public static void main(String[] args) {

//        User user = FileOperationsOnLoginAndSignup.findSpecificUser("hin");
//        new Manager.AdminScreen();
//        new RemoveItem();
//        new UpdateItem();
//        new Cart(user);
//        new Inventory();
//        new AvailableItems();
//        new HomeScreen(user);
//        new AddItems();
          new LoginScreenUser();
//            new Menu();
//                new Edit();
//        Admin admin = new Admin("admin","admin123");
//        FileOperationsOnAdmin.writeToFile(admin);

    }

}
